-- ============================================================
-- Breuta Coffee Shop - Vulnerable Lab Database
-- ============================================================

USE breuta_db;

-- ─── Users (customers) ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user VARCHAR(100) NOT NULL,
    pass VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    role VARCHAR(20) DEFAULT 'customer',
    balance DECIMAL(10,2) DEFAULT 50.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (user, pass, email, role, balance) VALUES
('anna',          'password123',     'anna@breuta.co',    'admin',    1000.00),
('bob_smith',     'coffee2024',      'bob@example.com',   'customer', 50.00),
('charlie',       'latte_lover',     'charlie@example.com','customer', 75.50),
('diana_w',       'espresso99',      'diana@example.com', 'customer', 30.00),
('eve_hacker',    'h4x0r_pass',      'eve@darknet.com',   'customer', 0.01);

-- ─── Employees ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'barista',
    department VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PHP type juggling: hash starts with 0e (magic hash)
-- "240610708" MD5 = 0e462097431906509019562988736854
-- "QNKCDZO"  MD5 = 0e830400451993494058024219903391
-- Both are "equal" with loose == comparison in PHP
INSERT INTO employees (username, password_hash, role, department) VALUES
('admin_emp',   '0e462097431906509019562988736854', 'manager',  'Operations'),  -- magic hash bypass
('barista01',   md5('brewtiful'),                   'barista',  'Floor'),
('barista02',   md5('coffeetime'),                  'barista',  'Floor'),
('inventory01', md5('stockroom1'),                  'inventory','Warehouse'),
('hr_jane',     md5('hr_secure99'),                 'hr',       'Human Resources');

-- ─── Coffee Products ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    origin VARCHAR(100),
    roast_level INT,           -- 1 to 5
    age_year INT,
    description TEXT,
    price DECIMAL(10,2),
    stock INT DEFAULT 100,
    image_url VARCHAR(500)
);

INSERT INTO products (name, origin, roast_level, age_year, description, price, stock, image_url) VALUES
('Ethiopian Yirgacheffe',  'Ethiopia',    1, 2022, 'Light fruity and floral notes with citrus finish.',       12.99, 80,  '/assets/img/products/eth_yirg.jpg'),
('Colombian Supremo',      'Colombia',    2, 2021, 'Medium roast with caramel sweetness and mild acidity.',   11.49, 120, '/assets/img/products/col_sup.jpg'),
('Brazilian Santos',       'Brazil',      3, 2020, 'Balanced body with chocolate and nutty undertones.',      10.99, 90,  '/assets/img/products/bra_san.jpg'),
('Guatemalan Antigua',     'Guatemala',   4, 2019, 'Dark roast, smoky, spicy with a rich full body.',         13.49, 60,  '/assets/img/products/gua_ant.jpg'),
('Sumatra Mandheling',     'Indonesia',   5, 2018, 'Extra dark, earthy, herbal with low acidity.',            14.99, 45,  '/assets/img/products/sum_man.jpg'),
('Kenya AA',               'Kenya',       2, 2022, 'Bright acidity with blackcurrant and wine notes.',        15.99, 70,  '/assets/img/products/ken_aa.jpg'),
('Costa Rica Tarrazu',     'Costa Rica',  3, 2021, 'Clean cup with honey-like sweetness and mild citrus.',    12.49, 85,  '/assets/img/products/cr_tar.jpg');

-- ─── Orders ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    total_price DECIMAL(10,2),
    status VARCHAR(50) DEFAULT 'pending',
    coupon_code VARCHAR(50),
    discount_applied DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

INSERT INTO orders (user_id, product_id, quantity, total_price, status) VALUES
(2, 1, 2, 25.98, 'completed'),
(2, 3, 1, 10.99, 'completed'),
(3, 2, 3, 34.47, 'pending'),
(4, 5, 1, 14.99, 'completed'),
(2, 6, 2, 31.98, 'pending');

-- ─── XSS Comments (product reviews) ─────────────────────────
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    user_id INT,
    username VARCHAR(100),
    comment TEXT,
    rating INT DEFAULT 5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO reviews (product_id, user_id, username, comment, rating) VALUES
(1, 2, 'bob_smith', 'Great light roast!', 5),
(2, 3, 'charlie',   'Very smooth coffee.', 4);

-- ─── Coupons (Business Logic) ────────────────────────────────
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    discount_percent DECIMAL(5,2),
    is_active TINYINT(1) DEFAULT 1,
    usage_count INT DEFAULT 0,
    max_usage INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO coupons (code, discount_percent, max_usage) VALUES
('WELCOME10', 10.00, 100),
('FREECOFFEE', 100.00, 1),
('SALE50',    50.00,  5);

-- ─── SSRF Fetch Logs ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ssrf_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    requested_url TEXT,
    fetched_by INT,
    result TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─── Sessions (Flask tokens) ─────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    token VARCHAR(512),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
