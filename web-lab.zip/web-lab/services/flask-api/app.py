#!/usr/bin/env python3
"""
Breuta Coffee Shop - Flask API Backend
Vulnerabilities implemented: BOLA, BFLA, SSRF, Business Logic
"""

import os, jwt, requests, pymysql
from flask import Flask, request, jsonify, g
from flask_cors import CORS
from functools import wraps
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

SECRET_KEY  = os.environ.get("SECRET_KEY", "super_insecure_secret_123")
DB_HOST     = os.environ.get("DB_HOST", "mysql-db")
DB_USER     = os.environ.get("DB_USER", "breuta")
DB_PASS     = os.environ.get("DB_PASS", "breuta_pass")
DB_NAME     = os.environ.get("DB_NAME", "breuta_db")


# ─── DB helper ────────────────────────────────────────────────
def get_db():
    return pymysql.connect(
        host=DB_HOST, user=DB_USER, password=DB_PASS,
        database=DB_NAME, cursorclass=pymysql.cursors.DictCursor,
        autocommit=True
    )

def query(sql, args=None, one=False):
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, args or ())
            return cur.fetchone() if one else cur.fetchall()
    finally:
        conn.close()

def execute(sql, args=None):
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, args or ())
        conn.commit()
    finally:
        conn.close()


# ─── JWT helpers ──────────────────────────────────────────────
def create_token(user_id, role):
    payload = {
        "user_id": user_id,
        "role":    role,
        "exp":     datetime.utcnow() + timedelta(hours=8)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def decode_token(token):
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    except Exception:
        return None

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        token = auth.replace("Bearer ", "").strip()
        if not token:
            # Also try cookie
            token = request.cookies.get("breuta_token", "")
        payload = decode_token(token)
        if not payload:
            return jsonify({"error": "Unauthorized"}), 401
        g.current_user = payload
        return f(*args, **kwargs)
    return decorated


# ═══════════════════════════════════════════════════════════════
# AUTH endpoints
# ═══════════════════════════════════════════════════════════════

@app.route("/api/auth/login", methods=["POST"])
def api_login():
    """Customer login → JWT token"""
    data = request.get_json() or {}
    username = data.get("username", "")
    password = data.get("password", "")

    user = query(
        "SELECT id, user, role FROM users WHERE user=%s AND pass=%s",
        (username, password), one=True
    )
    if not user:
        return jsonify({"error": "Invalid credentials"}), 401

    token = create_token(user["id"], user["role"])
    return jsonify({
        "token":   token,
        "user_id": user["id"],
        "role":    user["role"],
        "message": "Login successful"
    })

@app.route("/api/auth/register", methods=["POST"])
def api_register():
    data = request.get_json() or {}
    execute(
        "INSERT INTO users (user, pass, email) VALUES (%s, %s, %s)",
        (data.get("username"), data.get("password"), data.get("email", ""))
    )
    return jsonify({"message": "Registered successfully"}), 201


# ═══════════════════════════════════════════════════════════════
# PRODUCTS (public)
# ═══════════════════════════════════════════════════════════════

@app.route("/api/products", methods=["GET"])
def list_products():
    products = query("SELECT * FROM products ORDER BY roast_level")
    return jsonify(products)

@app.route("/api/products/<int:pid>", methods=["GET"])
def get_product(pid):
    p = query("SELECT * FROM products WHERE id=%s", (pid,), one=True)
    if not p:
        return jsonify({"error": "Not found"}), 404
    return jsonify(p)


# ═══════════════════════════════════════════════════════════════
# ORDERS  ← BOLA vulnerability
# Any authenticated user can read ANY order by ID
# ═══════════════════════════════════════════════════════════════

@app.route("/api/orders", methods=["GET"])
@token_required
def list_my_orders():
    """Lists only current user's orders — but /api/orders/<id> is broken (BOLA)"""
    uid = g.current_user["user_id"]
    orders = query(
        "SELECT o.*, p.name as product_name FROM orders o "
        "JOIN products p ON o.product_id=p.id WHERE o.user_id=%s",
        (uid,)
    )
    return jsonify(orders)

@app.route("/api/orders/<int:oid>", methods=["GET"])
@token_required
def get_order(oid):
    """
    ⚠️  BOLA VULNERABILITY ⚠️
    No ownership check! Any authenticated user can fetch any order by ID.
    Should check: order.user_id == g.current_user['user_id']
    """
    order = query(
        "SELECT o.*, p.name as product_name, u.email as customer_email "
        "FROM orders o JOIN products p ON o.product_id=p.id "
        "JOIN users u ON o.user_id=u.id WHERE o.id=%s",
        (oid,), one=True
    )
    if not order:
        return jsonify({"error": "Order not found"}), 404
    # Bug: returns order regardless of who is asking
    return jsonify(order)

@app.route("/api/orders", methods=["POST"])
@token_required
def place_order():
    data  = request.get_json() or {}
    uid   = g.current_user["user_id"]
    pid   = data.get("product_id")
    qty   = int(data.get("quantity", 1))
    coupon = data.get("coupon_code", "")

    product = query("SELECT * FROM products WHERE id=%s", (pid,), one=True)
    if not product:
        return jsonify({"error": "Product not found"}), 404

    total = float(product["price"]) * qty
    discount = 0.0

    # ─── Business Logic Vulnerability ──────────────────────
    # Coupon re-use: usage_count is never incremented server-side properly
    # Race condition / no atomic check
    if coupon:
        c = query("SELECT * FROM coupons WHERE code=%s AND is_active=1", (coupon,), one=True)
        if c:
            # BUG: Check happens but update is non-atomic; also negative qty allowed
            discount = total * (float(c["discount_percent"]) / 100)
            total    = total - discount
            # Intentional bug: usage_count NOT updated → infinite reuse of FREECOFFEE

    # BUG: negative quantity not validated → negative total possible
    execute(
        "INSERT INTO orders (user_id, product_id, quantity, total_price, coupon_code, discount_applied) "
        "VALUES (%s,%s,%s,%s,%s,%s)",
        (uid, pid, qty, total, coupon, discount)
    )
    return jsonify({"message": "Order placed", "total": total, "discount": discount}), 201


# ═══════════════════════════════════════════════════════════════
# ADMIN endpoints  ← BFLA vulnerability
# ═══════════════════════════════════════════════════════════════

@app.route("/api/admin/users", methods=["GET"])
@token_required
def admin_list_users():
    """
    ⚠️  BFLA VULNERABILITY ⚠️
    Checks for 'admin' role but the check can be bypassed by modifying
    the JWT payload (weak secret + algorithm confusion).
    Also: endpoint exposed, no IP restriction.
    """
    role = g.current_user.get("role", "")
    if role != "admin":
        # Intentional weak check: role comes from JWT, secret is weak
        return jsonify({"error": "Forbidden — admin only"}), 403
    users = query("SELECT id, user, email, role, balance FROM users")
    return jsonify(users)

@app.route("/api/admin/users/<int:uid>/role", methods=["PUT"])
@token_required
def admin_change_role(uid):
    """
    ⚠️  BFLA VULNERABILITY ⚠️
    Any user who can forge an 'admin' JWT can escalate any other user's role.
    """
    role = g.current_user.get("role", "")
    if role != "admin":
        return jsonify({"error": "Forbidden"}), 403
    data    = request.get_json() or {}
    new_role = data.get("role", "customer")
    execute("UPDATE users SET role=%s WHERE id=%s", (new_role, uid))
    return jsonify({"message": f"User {uid} role updated to {new_role}"})

@app.route("/api/admin/orders", methods=["GET"])
@token_required
def admin_list_orders():
    """BFLA: same pattern — only checks JWT role"""
    role = g.current_user.get("role", "")
    if role != "admin":
        return jsonify({"error": "Forbidden"}), 403
    orders = query(
        "SELECT o.*, u.user as customer, p.name as product "
        "FROM orders o JOIN users u ON o.user_id=u.id "
        "JOIN products p ON o.product_id=p.id ORDER BY o.created_at DESC"
    )
    return jsonify(orders)


# ═══════════════════════════════════════════════════════════════
# SSRF vulnerability
# ═══════════════════════════════════════════════════════════════

@app.route("/api/fetch-preview", methods=["POST"])
@token_required
def ssrf_fetch():
    """
    ⚠️  SSRF VULNERABILITY ⚠️
    Fetches any URL provided by the user — no whitelist, no filtering.
    Can be used to reach internal services, AWS metadata, etc.
    Try: http://169.254.169.254/latest/meta-data/
    """
    data = request.get_json() or {}
    url  = data.get("url", "")

    if not url:
        return jsonify({"error": "URL required"}), 400

    try:
        # No timeout restriction that matters, no URL validation
        resp = requests.get(url, timeout=10, allow_redirects=True,
                            headers={"User-Agent": "BreutaBot/1.0"})
        content = resp.text[:5000]  # limit output
    except Exception as e:
        content = f"Error: {str(e)}"

    # Log to DB
    uid = g.current_user.get("user_id")
    execute("INSERT INTO ssrf_logs (requested_url, fetched_by, result) VALUES (%s,%s,%s)",
            (url, uid, content[:2000]))

    return jsonify({
        "url":        url,
        "status":     resp.status_code if 'resp' in dir() else 0,
        "content":    content
    })


# ═══════════════════════════════════════════════════════════════
# User profile (BOLA on profile too)
# ═══════════════════════════════════════════════════════════════

@app.route("/api/users/<int:uid>", methods=["GET"])
@token_required
def get_user_profile(uid):
    """
    ⚠️  BOLA VULNERABILITY ⚠️
    No check that uid == g.current_user['user_id']
    Any logged-in user can view any other user's profile.
    """
    user = query(
        "SELECT id, user, email, role, balance, created_at FROM users WHERE id=%s",
        (uid,), one=True
    )
    if not user:
        return jsonify({"error": "User not found"}), 404
    return jsonify(user)

@app.route("/api/users/<int:uid>/balance", methods=["PUT"])
@token_required
def update_balance(uid):
    """BOLA: user can update their own balance — no server validation of amount"""
    # Bug: no check that uid == current user; also amount not validated
    data   = request.get_json() or {}
    amount = data.get("amount", 0)
    execute("UPDATE users SET balance = balance + %s WHERE id=%s", (amount, uid))
    return jsonify({"message": "Balance updated"})


# ─── Health ────────────────────────────────────────────────────
@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "service": "breuta-flask-api"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
