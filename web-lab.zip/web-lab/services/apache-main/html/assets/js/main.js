// Breuta Coffee – main.js

// Roast level selector
document.querySelectorAll('.roast-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.roast-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
  });
});

// Token management
const breuta = {
  getToken: () => localStorage.getItem('breuta_token'),
  setToken: (t) => localStorage.setItem('breuta_token', t),
  clearToken: () => localStorage.removeItem('breuta_token'),

  authHeaders: () => ({
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + (localStorage.getItem('breuta_token') || '')
  }),

  // Generic API caller
  async api(method, path, body) {
    const opts = { method, headers: breuta.authHeaders() };
    if (body) opts.body = JSON.stringify(body);
    const r = await fetch('/api' + path, opts);
    return r.json();
  }
};

// Flash messages
function showAlert(msg, type='info') {
  const div = document.createElement('div');
  div.className = `alert alert-${type}`;
  div.textContent = msg;
  document.body.insertBefore(div, document.body.children[1]);
  setTimeout(() => div.remove(), 5000);
}
