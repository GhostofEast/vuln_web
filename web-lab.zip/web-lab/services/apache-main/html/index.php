<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Breuta Coffee – Premium Coffee Experience</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<?php include '/var/www/html/includes/navbar.php'; ?>

<!-- Hero -->
<section class="hero">
  <div class="hero-content">
    <h1>☕ Breuta Coffee</h1>
    <p>Premium single-origin coffees, roasted to perfection.</p>
    <a href="/shop/" class="btn-primary">Shop Now</a>
    <a href="/vuln/sqli/" class="btn-secondary">Explore Roast Levels</a>
  </div>
</section>

<!-- Features -->
<section class="features">
  <div class="container">
    <div class="feature-grid">
      <div class="feature-card">
        <span class="icon">🌍</span>
        <h3>Single Origin</h3>
        <p>Sourced directly from farms across Ethiopia, Colombia, Brazil and beyond.</p>
      </div>
      <div class="feature-card">
        <span class="icon">🔥</span>
        <h3>5 Roast Levels</h3>
        <p>From light floral to extra-dark earthy — find your perfect roast.</p>
        <a href="/vuln/sqli/">Browse by Roast →</a>
      </div>
      <div class="feature-card">
        <span class="icon">📦</span>
        <h3>Fresh Delivery</h3>
        <p>Roasted to order and shipped within 48 hours.</p>
      </div>
      <div class="feature-card">
        <span class="icon">🎁</span>
        <h3>Loyalty Coupons</h3>
        <p>Use code <strong>WELCOME10</strong> for 10% off your first order.</p>
        <a href="/shop/cart/">Go to Cart →</a>
      </div>
    </div>
  </div>
</section>

<!-- Lab Navigation Banner -->
<section class="lab-nav">
  <div class="container">
    <h2>🔬 Lab Exercise Areas</h2>
    <div class="lab-grid">
      <a href="/vuln/sqli/"       class="lab-card"><span>💉</span><br>SQLi<br><small>Roast Levels</small></a>
      <a href="/vuln/upload/"     class="lab-card"><span>📂</span><br>File Upload<br><small>Profile Images</small></a>
      <a href="/vuln/bola/"       class="lab-card"><span>🔓</span><br>BOLA<br><small>Order Access</small></a>
      <a href="/vuln/bfla/"       class="lab-card"><span>🛡️</span><br>BFLA<br><small>Admin Functions</small></a>
      <a href="/vuln/xss/"        class="lab-card"><span>🧨</span><br>Stored XSS<br><small>Reviews</small></a>
      <a href="/vuln/ssrf/"       class="lab-card"><span>🌐</span><br>SSRF<br><small>Link Preview</small></a>
      <a href="/vuln/bizlogic/"   class="lab-card"><span>💼</span><br>Business Logic<br><small>Coupons</small></a>
      <a href="http://login.breuta.co/" class="lab-card"><span>👤</span><br>PHP Type Juggling<br><small>Employee Login</small></a>
    </div>
  </div>
</section>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
</body>
</html>
