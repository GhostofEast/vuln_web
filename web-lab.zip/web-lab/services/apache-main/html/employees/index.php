<?php
/**
 * ══════════════════════════════════════════════════
 * VULNERABILITY #8: PHP Type Juggling Authentication Bypass
 * Lab: Employee Login Portal (login.breuta.co)
 *
 * Vuln: Uses loose comparison (==) instead of strict (===)
 *       to compare MD5 hashes.
 *
 * PHP "magic hashes" — strings whose MD5 begins with "0e"
 * are interpreted as scientific notation (0 × 10^n = 0).
 * Any two 0e hashes are "equal" under == !
 *
 * Database stores admin_emp's password hash as:
 *   0e462097431906509019562988736854  (MD5 of "240610708")
 *
 * Login bypass:
 *   Username: admin_emp
 *   Password: QNKCDZO   (MD5 = 0e830400451993494058024219903391)
 *   Both hashes start with 0e → 0 == 0 → TRUE → access granted!
 *
 * Other magic hash strings: 240610708, aabg74j, aabC9RqS
 * ══════════════════════════════════════════════════
 */

session_start();

$error   = '';
$success = '';

include '/var/www/html/includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username && $password) {
        $conn     = get_db();
        $stmt     = $conn->prepare("SELECT id, username, role, department, password_hash FROM employees WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result   = $stmt->get_result();
        $employee = $result->fetch_assoc();
        $stmt->close();
        $conn->close();

        if ($employee) {
            $input_hash = md5($password);

            // ⚠️  TYPE JUGGLING VULNERABILITY — loose == comparison
            // Should be: $employee['password_hash'] === $input_hash
            if ($employee['password_hash'] == $input_hash) {
                $_SESSION['emp_id']       = $employee['id'];
                $_SESSION['emp_username'] = $employee['username'];
                $_SESSION['emp_role']     = $employee['role'];
                $success = "Welcome, " . htmlspecialchars($employee['username']) . "! You are logged in as " . htmlspecialchars($employee['role']) . ".";
            } else {
                $error = "Invalid credentials.";
            }
        } else {
            $error = "Invalid credentials.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Employee Login | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
<style>
  body { background: #1a1008; display: flex; flex-direction: column; min-height: 100vh; }
  .login-wrapper {
    display: flex; justify-content: center; align-items: center;
    flex: 1; padding: 2rem;
  }
  .login-box {
    background: white; border-radius: 12px; padding: 2.5rem;
    max-width: 480px; width: 100%;
    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
  }
  .login-logo { text-align: center; margin-bottom: 2rem; }
  .login-logo h1 { color: #4a2c17; font-size: 2rem; }
  .login-logo p  { color: #777; font-size: .9rem; }
  .hint-box { background: #fff8e1; border: 1px solid #ffc107; border-radius: 6px; padding: 1rem; margin-top: 1.5rem; font-size: .85rem; }
  .hint-box h4 { color: #856404; margin-bottom: .5rem; }
  .success-box { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 6px; padding: 1rem; }
  .emp-panel { background: #f8f9fa; border-radius: 8px; padding: 1.5rem; margin-top: 1.5rem; }
</style>
</head>
<body>

<div class="login-wrapper">
  <div class="login-box">
    <div class="login-logo">
      <h1>☕ Breuta Coffee</h1>
      <p>Employee Portal — login.breuta.co</p>
    </div>

    <?php if ($success): ?>
      <div class="success-box">
        <strong>✅ Access Granted!</strong><br>
        <?= $success ?>
        <div class="emp-panel">
          <strong>🏢 Employee Dashboard</strong>
          <ul style="margin-top:.5rem; margin-left:1rem;">
            <li>Role: <strong><?= htmlspecialchars($_SESSION['emp_role']) ?></strong></li>
            <li><a href="/employees/dashboard.php">View Dashboard</a></li>
            <li><a href="/employees/logout.php">Logout</a></li>
          </ul>
        </div>
      </div>
    <?php else: ?>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php endif; ?>

      <form method="POST">
        <div class="form-group">
          <label>Employee Username</label>
          <input type="text" name="username" placeholder="Enter username"
                 value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" autofocus>
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" placeholder="Enter password">
        </div>
        <button type="submit" style="width:100%;">Login to Employee Portal</button>
      </form>

    <?php endif; ?>

    <div class="hint-box">
      <h4>🧑‍🎓 Lab Exercise: PHP Type Juggling</h4>
      <p>The login uses <code>md5($password) == $stored_hash</code> (loose comparison).<br>
      PHP compares hashes starting with <code>0e</code> as the number <code>0</code>.</p>
      <p style="margin-top:.5rem;"><strong>Bypass credentials:</strong></p>
      <table style="width:100%; font-size:.82rem; border-collapse: collapse;">
        <tr><th style="text-align:left; padding:.2rem .5rem;">Username</th><th style="text-align:left; padding:.2rem .5rem;">Password</th><th style="text-align:left; padding:.2rem .5rem;">Why</th></tr>
        <tr>
          <td style="padding:.2rem .5rem;"><code>admin_emp</code></td>
          <td style="padding:.2rem .5rem;"><code>QNKCDZO</code></td>
          <td style="padding:.2rem .5rem;">MD5 starts with 0e</td>
        </tr>
        <tr>
          <td style="padding:.2rem .5rem;"><code>admin_emp</code></td>
          <td style="padding:.2rem .5rem;"><code>240610708</code></td>
          <td style="padding:.2rem .5rem;">MD5 starts with 0e</td>
        </tr>
        <tr>
          <td style="padding:.2rem .5rem;"><code>admin_emp</code></td>
          <td style="padding:.2rem .5rem;"><code>aabC9RqS</code></td>
          <td style="padding:.2rem .5rem;">MD5 starts with 0e</td>
        </tr>
      </table>
      <p style="margin-top:.5rem;"><strong>Stored hash:</strong> <code style="font-size:.75rem;">0e462097431906509019562988736854</code></p>
      <p><strong>QNKCDZO hash:</strong> <code style="font-size:.75rem;">0e830400451993494058024219903391</code></p>
    </div>

  </div>
</div>

<footer style="text-align:center; color:#666; padding:1rem; background:#1a1008;">
  <p>© 2024 Breuta Coffee — Employee Portal | <a href="http://breuta.co/" style="color:#c8973a;">Main Site</a></p>
</footer>

</body>
</html>
