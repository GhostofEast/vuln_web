<?php
session_start();
if (empty($_SESSION['emp_id'])) {
    header('Location: /');
    exit;
}
include '/var/www/html/includes/db.php';
$conn = get_db();
$employees = $conn->query("SELECT id, username, role, department FROM employees")->fetch_all(MYSQLI_ASSOC);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Employee Dashboard | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<nav class="navbar">
  <div class="nav-brand"><a href="http://breuta.co/">☕ Breuta Coffee</a></div>
  <ul class="nav-links">
    <li><a href="/employees/dashboard.php">Dashboard</a></li>
    <li><a href="/employees/logout.php">Logout (<?= htmlspecialchars($_SESSION['emp_username']) ?>)</a></li>
  </ul>
</nav>

<div class="page-header">
  <div class="container">
    <h1>🏢 Employee Dashboard</h1>
    <p>Welcome back, <?= htmlspecialchars($_SESSION['emp_username']) ?>! Role: <strong><?= htmlspecialchars($_SESSION['emp_role']) ?></strong></p>
  </div>
</div>

<div class="container">
  <div class="alert alert-success" style="margin-top:1rem;">
    ✅ Successfully authenticated via PHP type juggling bypass!
  </div>

  <div class="card">
    <h2>Employee Directory</h2>
    <table>
      <tr><th>ID</th><th>Username</th><th>Role</th><th>Department</th></tr>
      <?php foreach ($employees as $e): ?>
      <tr>
        <td><?= $e['id'] ?></td>
        <td><?= htmlspecialchars($e['username']) ?></td>
        <td><?= htmlspecialchars($e['role']) ?></td>
        <td><?= htmlspecialchars($e['department']) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>

  <div class="card">
    <h2>🏷️ What Happened?</h2>
    <p>PHP compared the stored hash <code>0e462097431906509019562988736854</code> with the input hash using <code>==</code>:</p>
    <pre style="background:#1e1e1e; color:#0f0; padding:1rem; border-radius:6px; font-family:monospace; font-size:.9rem;">
// PHP code (vulnerable):
if ($employee['password_hash'] == md5($password)) { ... }

// md5("QNKCDZO")   = "0e830400451993494058024219903391"
// stored_hash      = "0e462097431906509019562988736854"
//
// PHP sees: "0e83..." == "0e46..." → 0 == 0 → TRUE!
// Because 0e... is treated as floating point: 0 × 10^n = 0

// Fix: use === (strict comparison)
if ($employee['password_hash'] === md5($password)) { ... }
    </pre>
  </div>
</div>

<footer class="footer">
  <div class="container">
    <p>© 2024 Breuta Coffee | Employee Portal</p>
  </div>
</footer>

</body>
</html>
