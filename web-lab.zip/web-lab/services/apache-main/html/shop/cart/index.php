<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Shopping Cart | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>🛒 Your Cart</h1>
  </div>
</div>

<div class="container">
  <div class="card">
    <h2>Cart Items</h2>
    <div id="cart-items"></div>
    <div id="cart-total" style="font-size:1.2rem; font-weight:700; margin-top:1rem; color:#4a2c17;"></div>
  </div>

  <div class="card">
    <h2>Checkout</h2>
    <p>Login first, then place your order via the API.</p>
    <div class="form-group">
      <label>Username</label><input type="text" id="username" value="bob_smith">
    </div>
    <div class="form-group">
      <label>Password</label><input type="password" id="password" value="coffee2024">
    </div>
    <div class="form-group">
      <label>Coupon Code (optional)</label>
      <input type="text" id="coupon" placeholder="e.g. WELCOME10">
    </div>
    <button onclick="loginAndOrder()">Login & Place Order</button>
    <div id="checkout-result" class="json-block" style="margin-top:1rem; min-height:40px;"></div>
  </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
<script>
function renderCart() {
  const cart  = JSON.parse(localStorage.getItem('breuta_cart') || '[]');
  const items = document.getElementById('cart-items');
  const total = document.getElementById('cart-total');
  if (cart.length === 0) {
    items.innerHTML = '<p style="color:#999;">Your cart is empty. <a href="/shop/">Browse products</a></p>';
    total.textContent = '';
    return;
  }
  let html = '<table><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr>';
  let sum  = 0;
  cart.forEach((item, i) => {
    const sub = (item.price * item.qty).toFixed(2);
    sum += item.price * item.qty;
    html += `<tr>
      <td>${item.name}</td>
      <td>$${item.price}</td>
      <td><input type="number" value="${item.qty}" min="1" onchange="updateQty(${i}, this.value)" style="width:60px;"></td>
      <td>$${sub}</td>
      <td><button onclick="removeItem(${i})" style="background:#c0392b; padding:.3rem .7rem;">✕</button></td>
    </tr>`;
  });
  html += '</table>';
  items.innerHTML = html;
  total.textContent = `Total: $${sum.toFixed(2)}`;
}
function updateQty(idx, qty) {
  let cart = JSON.parse(localStorage.getItem('breuta_cart') || '[]');
  cart[idx].qty = parseInt(qty);
  localStorage.setItem('breuta_cart', JSON.stringify(cart));
  renderCart();
}
function removeItem(idx) {
  let cart = JSON.parse(localStorage.getItem('breuta_cart') || '[]');
  cart.splice(idx, 1);
  localStorage.setItem('breuta_cart', JSON.stringify(cart));
  renderCart();
}
async function loginAndOrder() {
  const loginRes = await breuta.api('POST', '/auth/login', {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
  });
  if (!loginRes.token) {
    document.getElementById('checkout-result').textContent = JSON.stringify(loginRes, null, 2);
    return;
  }
  breuta.setToken(loginRes.token);
  const cart   = JSON.parse(localStorage.getItem('breuta_cart') || '[]');
  const coupon = document.getElementById('coupon').value;
  const results = [];
  for (const item of cart) {
    const r = await breuta.api('POST', '/orders', {
      product_id: item.id,
      quantity:   item.qty,
      coupon_code: coupon
    });
    results.push(r);
  }
  document.getElementById('checkout-result').textContent = JSON.stringify(results, null, 2);
  if (results.every(r => r.message)) {
    localStorage.removeItem('breuta_cart');
    renderCart();
  }
}
renderCart();
</script>
</body>
</html>
