<?php
session_start();
include '/var/www/html/includes/db.php';

$message = '';
$type    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    $conn = get_db();
    $stmt = $conn->prepare("SELECT id, user, role FROM users WHERE user=? AND pass=?");
    $stmt->bind_param('ss', $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    $user   = $result->fetch_assoc();
    $stmt->close();
    $conn->close();

    if ($user) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['user'];
        $_SESSION['role']     = $user['role'];
        header('Location: /shop/');
        exit;
    } else {
        $message = 'Invalid username or password.';
        $type    = 'danger';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Customer Login | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>
<div class="container" style="max-width:420px; margin-top:4rem;">
  <div class="card">
    <h2>Customer Login</h2>
    <?php if ($message): ?>
      <div class="alert alert-<?= $type ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" placeholder="Your username" required>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Your password" required>
      </div>
      <button type="submit" style="width:100%;">Login</button>
    </form>
    <p style="margin-top:1rem; text-align:center; color:#777;">
      Test accounts: bob_smith / coffee2024, charlie / latte_lover
    </p>
  </div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
</body>
</html>
