<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Orders | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>📦 My Orders</h1>
    <p>View your order history and track deliveries</p>
  </div>
</div>

<div class="container">
  <div class="vuln-hint">
    <h4>💡 BOLA Hint</h4>
    <p>Try fetching <code>GET /api/orders/4</code> (which belongs to diana) while logged in as bob_smith. Notice that the API returns the order without checking ownership!</p>
  </div>

  <div class="card">
    <h2>Login First</h2>
    <div class="form-group"><label>Username</label><input type="text" id="username" value="bob_smith"></div>
    <div class="form-group"><label>Password</label><input type="password" id="password" value="coffee2024"></div>
    <button onclick="doLogin()">Login</button>
    <div id="login-status"></div>
  </div>

  <div class="card">
    <h2>My Orders</h2>
    <button onclick="loadOrders()">Load My Orders</button>
    <div id="orders-output" class="json-block" style="margin-top:1rem; min-height:60px;"></div>
  </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
<script>
async function doLogin() {
  const r = await breuta.api('POST', '/auth/login', {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
  });
  if (r.token) {
    breuta.setToken(r.token);
    document.getElementById('login-status').innerHTML = '<div class="alert alert-success" style="margin-top:.5rem;">✅ Logged in!</div>';
  }
}
async function loadOrders() {
  const r = await breuta.api('GET', '/orders');
  document.getElementById('orders-output').textContent = JSON.stringify(r, null, 2);
}
</script>
</body>
</html>
