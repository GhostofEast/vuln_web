<?php
session_start();
include '/var/www/html/includes/db.php';
$conn     = get_db();
$products = $conn->query("SELECT * FROM products ORDER BY roast_level")->fetch_all(MYSQLI_ASSOC);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Shop | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>☕ Our Coffee Selection</h1>
    <p>Single-origin beans from around the world, roasted to perfection</p>
  </div>
</div>

<div class="container">
  <div class="product-grid">
    <?php foreach ($products as $p): ?>
    <div class="product-card">
      <div style="background: linear-gradient(135deg, #c8a87a, #4a2c17); height:160px; display:flex; align-items:center; justify-content:center; font-size:3rem;">☕</div>
      <div class="p-body">
        <span class="roast-badge">Level <?= $p['roast_level'] ?></span>
        <h3><?= htmlspecialchars($p['name']) ?></h3>
        <p class="origin">🌍 <?= htmlspecialchars($p['origin']) ?> · <?= $p['age_year'] ?></p>
        <p style="font-size:.85rem; color:#666; margin:.5rem 0;"><?= htmlspecialchars($p['description']) ?></p>
        <div class="price">\$<?= number_format($p['price'], 2) ?></div>
        <button onclick="addToCart(<?= $p['id'] ?>, '<?= htmlspecialchars($p['name'], ENT_QUOTES) ?>', <?= $p['price'] ?>)">
          Add to Cart 🛒
        </button>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
<script>
function addToCart(id, name, price) {
  let cart = JSON.parse(localStorage.getItem('breuta_cart') || '[]');
  const existing = cart.find(i => i.id === id);
  if (existing) { existing.qty++; }
  else { cart.push({id, name, price, qty: 1}); }
  localStorage.setItem('breuta_cart', JSON.stringify(cart));
  showAlert(`✅ Added "${name}" to cart!`, 'success');
}
</script>
</body>
</html>
