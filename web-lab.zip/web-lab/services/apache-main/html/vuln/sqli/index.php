<?php
/**
 * ══════════════════════════════════════════════════
 * VULNERABILITY #1: SQL INJECTION
 * Lab: Roast Level Explorer
 *
 * Vuln: The 'level' GET parameter is inserted directly
 *       into a raw SQL query without sanitisation.
 *
 * Payload to try:
 *   ?level=1 UNION SELECT user,pass,NULL,NULL FROM users --
 *
 * Expected result: returns coffee row + injected user rows
 * ══════════════════════════════════════════════════
 */

include '/var/www/html/includes/db.php';

$level  = $_GET['level'] ?? '';
$result = [];
$error  = '';
$sql    = '';

if ($level !== '') {
    $conn = get_db();
    // ⚠️  INTENTIONALLY VULNERABLE — raw string interpolation
    $sql  = "SELECT roast_level AS level, name, origin, age_year AS age FROM products WHERE roast_level = $level";
    $res  = $conn->query($sql);
    if ($res === false) {
        $error = $conn->error;
    } else {
        while ($row = $res->fetch_assoc()) {
            $result[] = $row;
        }
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Roast Level Explorer | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>🔥 Coffee Roast Levels</h1>
    <p>Explore our coffees by roast level (1 = lightest, 5 = darkest)</p>
  </div>
</div>

<div class="container">

  <div class="vuln-hint">
    <h4>🧑‍🎓 Lab Exercise: SQL Injection</h4>
    <p>This page fetches coffee data based on the roast <strong>level</strong> parameter.<br>
       Try manipulating the URL parameter to extract unintended data from the database.</p>
    <code>GET /vuln/sqli/?level=1</code>
  </div>

  <!-- Roast Level Buttons -->
  <div class="roast-selector">
    <?php foreach([1,2,3,4,5] as $l): ?>
      <a href="?level=<?= $l ?>" class="roast-btn <?= ($level == $l ? 'active' : '') ?>">
        Level <?= $l ?>
      </a>
    <?php endforeach; ?>
  </div>

  <!-- Manual query form -->
  <div class="card">
    <h2>Manual Query</h2>
    <form method="GET" action="/vuln/sqli/">
      <div class="form-group">
        <label for="level">Roast Level (try injecting here)</label>
        <input type="text" id="level" name="level"
               value="<?= htmlspecialchars($level, ENT_QUOTES, 'UTF-8') ?>"
               placeholder="e.g. 1 or 1 UNION SELECT ...">
      </div>
      <button type="submit">Search</button>
    </form>

    <?php if ($sql): ?>
    <div style="margin-top:1rem;">
      <strong>Executed SQL:</strong>
      <code style="display:block; background:#f4f4f4; padding:.5rem; margin-top:.3rem; border-radius:4px; font-size:.85rem;">
        <?= htmlspecialchars($sql) ?>
      </code>
    </div>
    <?php endif; ?>
  </div>

  <!-- Results -->
  <?php if ($error): ?>
    <div class="alert alert-danger">SQL Error: <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if (!empty($result)): ?>
  <div class="card">
    <h2>Results</h2>
    <!-- JSON output (as the spec requires) -->
    <div class="json-block"><?php
      foreach ($result as $row) {
          echo json_encode([
              'level'  => $row['level'],
              'name'   => $row['name'],
              'origin' => $row['origin'],
              'age'    => $row['age'],
          ], JSON_PRETTY_PRINT) . "\n\n";
      }
    ?></div>

    <!-- Also as a table for readability -->
    <table style="margin-top:1.5rem;">
      <thead>
        <tr><th>Level</th><th>Name</th><th>Origin</th><th>Age</th></tr>
      </thead>
      <tbody>
        <?php foreach ($result as $row): ?>
        <tr>
          <td><?= $row['level'] ?></td>
          <td><?= $row['name']  ?></td>
          <td><?= $row['origin']?></td>
          <td><?= $row['age']   ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php elseif ($level !== '' && !$error): ?>
    <div class="alert alert-info">No results found for level: <?= htmlspecialchars($level) ?></div>
  <?php endif; ?>

  <div class="card" style="margin-top:2rem;">
    <h2>💡 Payload Hints</h2>
    <table>
      <tr><th>Goal</th><th>Payload (append to ?level=)</th></tr>
      <tr><td>Normal query</td>    <td><code>1</code></td></tr>
      <tr><td>Always true</td>     <td><code>1 OR 1=1 --</code></td></tr>
      <tr><td>Dump users</td>      <td><code>1 UNION SELECT user,pass,NULL,NULL FROM users -- </code></td></tr>
      <tr><td>Column count</td>    <td><code>1 ORDER BY 5 --</code></td></tr>
      <tr><td>DB version</td>      <td><code>1 UNION SELECT @@version,NULL,NULL,NULL -- </code></td></tr>
    </table>
  </div>

</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
</body>
</html>
