<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>BOLA Lab | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>🔓 BOLA – Broken Object Level Authorization</h1>
    <p>Access other users' orders by manipulating the order ID</p>
  </div>
</div>

<div class="container">

  <div class="vuln-hint">
    <h4>🧑‍🎓 Lab Exercise: BOLA (IDOR)</h4>
    <p>The <code>GET /api/orders/&lt;id&gt;</code> endpoint returns any order by ID without verifying that
    the order belongs to the authenticated user. Login as one user, then enumerate order IDs to access
    another user's order details.</p>
  </div>

  <!-- Step 1: Login -->
  <div class="card">
    <h2>Step 1 — Authenticate</h2>
    <p>Login to get your JWT token. Use credentials from the user table.</p>
    <div class="form-group">
      <label>Username</label>
      <input type="text" id="username" value="bob_smith">
    </div>
    <div class="form-group">
      <label>Password</label>
      <input type="password" id="password" value="coffee2024">
    </div>
    <button onclick="doLogin()">Login & Get Token</button>
    <div id="login-result" style="margin-top:1rem;"></div>
  </div>

  <!-- Step 2: Fetch own orders -->
  <div class="card">
    <h2>Step 2 — View My Orders</h2>
    <button onclick="getMyOrders()">Fetch My Orders</button>
    <div id="my-orders" class="json-block" style="margin-top:1rem; min-height:60px;"></div>
  </div>

  <!-- Step 3: BOLA — access any order -->
  <div class="card">
    <h2>Step 3 — BOLA: Access Any Order</h2>
    <p style="color:#c0392b; font-weight:600;">Try order IDs 1–10. You can access orders belonging to other users!</p>
    <div class="form-group">
      <label>Order ID to access</label>
      <input type="number" id="order-id" value="1" min="1">
    </div>
    <button onclick="getOrder()">Fetch Order (BOLA)</button>
    <div id="order-result" class="json-block" style="margin-top:1rem; min-height:60px;"></div>
  </div>

  <div class="card">
    <h2>💡 Curl Commands</h2>
    <pre style="background:#1e1e1e; color:#d4d4d4; padding:1rem; border-radius:6px; overflow-x:auto; font-size:.85rem;">
# 1. Login
curl -X POST http://breuta.co/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"bob_smith","password":"coffee2024"}'

# 2. Access YOUR order (order 2 belongs to bob)
curl http://breuta.co/api/orders/2 \
  -H "Authorization: Bearer &lt;TOKEN&gt;"

# 3. BOLA — access diana's order (order 4)
curl http://breuta.co/api/orders/4 \
  -H "Authorization: Bearer &lt;TOKEN&gt;"
    </pre>
  </div>

</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
<script>
async function doLogin() {
  const r = await breuta.api('POST', '/auth/login', {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
  });
  if (r.token) {
    breuta.setToken(r.token);
    document.getElementById('login-result').innerHTML =
      `<div class="alert alert-success">✅ Logged in! Token stored.<br><code style="font-size:.75rem;">${r.token.substring(0,60)}...</code></div>`;
  } else {
    document.getElementById('login-result').innerHTML =
      `<div class="alert alert-danger">❌ ${r.error || 'Login failed'}</div>`;
  }
}

async function getMyOrders() {
  const r = await breuta.api('GET', '/orders');
  document.getElementById('my-orders').textContent = JSON.stringify(r, null, 2);
}

async function getOrder() {
  const id = document.getElementById('order-id').value;
  const r = await breuta.api('GET', `/orders/${id}`);
  document.getElementById('order-result').textContent = JSON.stringify(r, null, 2);
}
</script>
</body>
</html>
