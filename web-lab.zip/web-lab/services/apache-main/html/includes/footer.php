<footer class="footer">
  <div class="container">
    <p>© 2024 Breuta Coffee Co. | <a href="http://login.breuta.co/">Employee Portal</a></p>
    <p style="font-size:0.8em; color:#888;">This is a vulnerable application for educational purposes only.</p>
  </div>
</footer>
