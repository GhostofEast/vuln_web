<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<nav class="navbar">
  <div class="nav-brand">
    <a href="/">☕ Breuta Coffee</a>
  </div>
  <ul class="nav-links">
    <li><a href="/">Home</a></li>
    <li><a href="/shop/">Shop</a></li>
    <li><a href="/vuln/sqli/">Roast Levels</a></li>
    <li><a href="/vuln/xss/">Reviews</a></li>
    <li><a href="/vuln/ssrf/">Link Preview</a></li>
    <li><a href="/shop/cart/">Cart</a></li>
    <?php if (isset($_SESSION['user_id'])): ?>
      <li><a href="/shop/orders/">My Orders</a></li>
      <li><a href="/shop/logout.php">Logout (<?= htmlspecialchars($_SESSION['username'] ?? 'User') ?>)</a></li>
    <?php else: ?>
      <li><a href="/shop/login.php">Login</a></li>
    <?php endif; ?>
  </ul>
</nav>
