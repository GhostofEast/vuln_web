<?php
// Shared DB connection for PHP pages
$db_host = 'mysql-db';
$db_user = 'breuta';
$db_pass = 'breuta_pass';
$db_name = 'breuta_db';

function get_db() {
    global $db_host, $db_user, $db_pass, $db_name;
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        die(json_encode(['error' => 'DB connection failed: ' . $conn->connect_error]));
    }
    return $conn;
}

// Helper: get current logged-in user from session
function get_current_user_id() {
    session_start();
    return $_SESSION['user_id'] ?? null;
}

function get_current_user_role() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    return $_SESSION['role'] ?? 'guest';
}
?>
