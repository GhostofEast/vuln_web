#!/bin/bash
# ============================================================
# Breuta Coffee Shop - Lab Setup Script
# Run this once before docker compose up
# ============================================================

set -e

echo "============================================"
echo "  Breuta Coffee Shop - Lab Setup"
echo "============================================"

# Add local DNS entries so breuta.co and login.breuta.co resolve to localhost
HOSTS_ENTRY_MAIN="127.0.0.1 breuta.co www.breuta.co"
HOSTS_ENTRY_LOGIN="127.0.0.1 login.breuta.co"

if ! grep -q "breuta.co" /etc/hosts; then
    echo "$HOSTS_ENTRY_MAIN" | sudo tee -a /etc/hosts
    echo "$HOSTS_ENTRY_LOGIN" | sudo tee -a /etc/hosts
    echo "[✓] Added breuta.co and login.breuta.co to /etc/hosts"
else
    echo "[i] breuta.co already in /etc/hosts"
fi

# Create uploads directory and ensure permissions
mkdir -p services/apache-main/html/shop/uploads
chmod 777 services/apache-main/html/shop/uploads
echo "[✓] Upload directory permissions set"

echo ""
echo "============================================"
echo "  Setup complete! Now run:"
echo "  sudo docker compose up --build"
echo ""
echo "  URLs:"
echo "  Main site:       http://breuta.co"
echo "  Employee login:  http://login.breuta.co"
echo "============================================"
